<!DOCTYPE html>
<html>
<head>
<title>Even News</title>
<meta charset="utf-8"/>
<meta name=viewport content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="css/even.css" />
<script type="text/javascript" src="js/password.js"></script>
</head>
<body id="body1">



<div class="twelve columns">
  <?php include("includes/header.php");?>
</div>

<div id="tabs">
<?php include("includes/navigation.php")?>
</div>
<div class="transbox">
<h1>About Us</h1>
<p>Our website is provide information about events that going to held in your near area, From concert music into workshop. 
Our goal is people not going to miss event that they like it. EvenNews also provide location by using google map. there are 4 pages in this website. main
page is page that contain information title, place and schedule event. second page is sign-up, this page is for user sign up to be a member.
third page is location event. this page is contain map location event by using google map. each marker contain information event that going happen in those location
last page is about us. this page is about information of event news.
 </p>
<h1>Contact Information</h1>
<p>Dimaz ardhi email:dimazboston@yahoo.com, phone:999999222</p>
</div>



<div class="footer1">
<?php include("includes/footer.php");?>
</div>



</body>
</html>
