<header>
    <h1>Event News</h1>
 </header>