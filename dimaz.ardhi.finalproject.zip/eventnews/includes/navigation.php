  <ul>
      <li id="one"><a href="index.php"><span>Main</span></a></li>
      <li id="two"><a href="form.php"><span>Sign Up</span></a></li>
      <li id="three"><a href="map.php"><span>Location Event</span></a></li>
      <li id="four"><a href="about.php"><span>About</span></a></li>
	</ul>


